package com.company.connection;

import java.sql.Connection;

public interface IDatabase {
    static Connection getConnection() {
        return null;
    }
}
